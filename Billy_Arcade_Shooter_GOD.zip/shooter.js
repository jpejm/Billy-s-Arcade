
class ShooterGame {
    constructor() {
        this.canvas = document.getElementById("shooterCanvas");
        this.ctx = this.canvas.getContext("2d");

        this.player = { x: 50, y: this.canvas.height / 2, size: 20, color: "lime" };
        this.bullets = [];
        this.enemies = [];

        this.score = 0;
        this.gameOver = false;

        this.speedMultiplier = 1;
        this.godMode = false;
        this.scoreMultiplier = 1;
        this.shootMode = "click";
        this.isMouseDown = false;
        this.shootCooldown = 0;
        this.fireRate = 10;

        this.startEnemySpawner();
        this.setupControls();
        this.gameLoop();
    }

    startEnemySpawner() {
        setInterval(() => {
            this.enemies.push({
                x: this.canvas.width,
                y: Math.random() * (this.canvas.height - 20),
                size: 20,
                speed: 2
            });
        }, 1200);
    }

    setupControls() {
        this.canvas.addEventListener("mousedown", () => {
            if (this.shootMode === "click") {
                this.shoot();
            } else {
                this.isMouseDown = true;
            }
        });

        this.canvas.addEventListener("mouseup", () => {
            this.isMouseDown = false;
        });

        document.addEventListener("keydown", (e) => {
            if (e.code === "KeyM") this.toggleShootMode();
        });
    }

    toggleShootMode() {
        this.shootMode = this.shootMode === "click" ? "hold" : "click";
    }

    shoot() {
        let amount = this.godMode ? 1000 : 1;

        for (let i = 0; i < amount; i++) {
            this.bullets.push({
                x: this.player.x + this.player.size,
                y: this.player.y + this.player.size / 2 + (Math.random() * 20 - 10),
                size: 5,
                dx: 6
            });
        }
    }

    activateCheat(code) {
        if (code === "Billy1314") {
            this.godMode = true;
            this.player.color = "gold";
            this.scoreMultiplier = 100000000;
            this.fireRate = 1;
            alert("GOD MODE ATIVADO");
        }

        if (code === "WSPEED") {
            this.speedMultiplier = 50;
            alert("WSPEED 50x ATIVADO");
        }
    }

    update() {
        if (this.shootMode === "hold" && this.isMouseDown) {
            if (this.shootCooldown <= 0) {
                this.shoot();
                this.shootCooldown = this.fireRate;
            }
        }

        if (this.shootCooldown > 0) this.shootCooldown--;

        this.bullets.forEach(b => b.x += b.dx * this.speedMultiplier);

        this.enemies.forEach(enemy => {
            enemy.x -= enemy.speed * this.speedMultiplier;

            if (!this.godMode &&
                enemy.x < this.player.x + this.player.size &&
                enemy.y < this.player.y + this.player.size &&
                enemy.y > this.player.y) {
                this.gameOver = true;
                this.saveScore();
            }
        });

        this.checkHits();
    }

    checkHits() {
        this.bullets.forEach((b, bi) => {
            this.enemies.forEach((e, ei) => {
                if (
                    b.x < e.x + e.size &&
                    b.x + b.size > e.x &&
                    b.y < e.y + e.size &&
                    b.y + b.size > e.y
                ) {
                    this.enemies.splice(ei, 1);
                    this.bullets.splice(bi, 1);
                    this.score += 10 * this.scoreMultiplier;
                }
            });
        });
    }

    draw() {
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

        this.ctx.fillStyle = this.player.color;
        this.ctx.fillRect(this.player.x, this.player.y, this.player.size, this.player.size);

        this.ctx.fillStyle = "white";
        this.bullets.forEach(b => this.ctx.fillRect(b.x, b.y, b.size, b.size));

        this.ctx.fillStyle = "red";
        this.enemies.forEach(e => this.ctx.fillRect(e.x, e.y, e.size, e.size));

        this.ctx.fillStyle = "white";
        this.ctx.fillText("Score: " + this.score, 10, 20);
        this.ctx.fillText("Speed: " + this.speedMultiplier + "x", 10, 40);
    }

    gameLoop() {
        if (!this.gameOver) {
            this.update();
            this.draw();
            requestAnimationFrame(() => this.gameLoop());
        }
    }

    saveScore() {
        let key = `shooter_${this.godMode ? "god" : "normal"}_${this.speedMultiplier}`;
        let scores = JSON.parse(localStorage.getItem(key)) || [];

        scores.push({ score: this.score });
        scores.sort((a, b) => b.score - a.score);
        scores = scores.slice(0, 50);

        localStorage.setItem(key, JSON.stringify(scores));
    }
}

const shooterGame = new ShooterGame();
