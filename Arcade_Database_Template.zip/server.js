
const express = require('express');
const app = express();
app.use(express.json());

let rankings = [];

app.post('/save', (req, res) => {
    rankings.push(req.body);
    rankings.sort((a,b)=>b.score-a.score);
    rankings = rankings.slice(0,100);
    res.json({status:"saved"});
});

app.get('/rankings', (req,res)=>{
    res.json(rankings);
});

app.listen(3000, ()=> console.log("DB running on port 3000"));
