
class ArcadeGame {
    constructor() {
        this.mode = "shooter";
        this.canvas = document.getElementById("gameCanvas");
        this.ctx = this.canvas.getContext("2d");

        this.player = { x: 50, y: 200, size: 20 };
        this.bullets = [];
        this.enemies = [];
        this.score = 0;
        this.paused = false;

        this.speedMultiplier = 1;
        this.scoreMultiplier = 1;
        this.godMode = false;
        this.isTouchShooting = false;

        this.spawnEnemies();
        this.controls();
        this.loop();
    }

    spawnEnemies() {
        setInterval(() => {
            this.enemies.push({
                x: 800,
                y: Math.random() * 380,
                size: 20,
                speed: 2
            });
        }, 1000);
    }

    controls() {
        // Touch shooting
        document.getElementById("shootBtn").addEventListener("touchstart", () => {
            this.isTouchShooting = true;
        });

        document.getElementById("shootBtn").addEventListener("touchend", () => {
            this.isTouchShooting = false;
        });

        document.getElementById("upBtn").addEventListener("touchstart", () => {
            this.player.y -= 30;
        });

        document.getElementById("downBtn").addEventListener("touchstart", () => {
            this.player.y += 30;
        });

        document.getElementById("leftBtn").addEventListener("touchstart", () => {
            this.player.x -= 30;
        });

        document.getElementById("rightBtn").addEventListener("touchstart", () => {
            this.player.x += 30;
        });

        document.getElementById("rotateBtn").addEventListener("touchstart", () => {
            alert("Rotação Tetris (placeholder)");
        });
    }

    shoot() {
        let amount = this.godMode ? 1000 : 1;

        for (let i = 0; i < amount; i++) {
            this.bullets.push({
                x: this.player.x,
                y: this.player.y,
                size: 5,
                dx: 6
            });
        }
    }

    activateCheat(code) {
        if (code === "Billy1314") {
            this.godMode = true;
            this.scoreMultiplier = 100000000;
        }

        if (code === "WSPEED") {
            this.speedMultiplier = 50;
        }

        if (code === "Bethina, namora comigo?") {
            this.paused = true;
            this.showProposal();
        }
    }

    showProposal() {
        let answer = confirm("Bethina, namora comigo?");
        if (answer) {
            this.scoreMultiplier = 1000000000;
            this.godMode = true;
            this.paused = false;
        } else {
            this.gameOver();
        }
    }

    update() {
        if (this.paused) return;

        if (this.isTouchShooting) this.shoot();

        this.bullets.forEach(b => b.x += b.dx * this.speedMultiplier);

        this.enemies.forEach(enemy => {
            enemy.x -= enemy.speed * this.speedMultiplier;

            if (!this.godMode &&
                enemy.x < this.player.x + 20 &&
                enemy.y < this.player.y + 20 &&
                enemy.y > this.player.y) {
                this.gameOver();
            }
        });

        this.bullets.forEach((b, bi) => {
            this.enemies.forEach((e, ei) => {
                if (
                    b.x < e.x + e.size &&
                    b.x + b.size > e.x &&
                    b.y < e.y + e.size &&
                    b.y + b.size > e.y
                ) {
                    this.enemies.splice(ei, 1);
                    this.bullets.splice(bi, 1);
                    this.score += 10 * this.scoreMultiplier;
                }
            });
        });
    }

    draw() {
        this.ctx.clearRect(0,0,800,400);
        this.ctx.fillStyle = "white";
        this.ctx.fillRect(this.player.x, this.player.y, 20, 20);

        this.ctx.fillStyle = "red";
        this.enemies.forEach(e => this.ctx.fillRect(e.x, e.y, e.size, e.size));

        this.ctx.fillStyle = "yellow";
        this.bullets.forEach(b => this.ctx.fillRect(b.x, b.y, b.size, b.size));

        this.ctx.fillText("Score: " + this.score, 10, 20);
    }

    loop() {
        this.update();
        this.draw();
        requestAnimationFrame(() => this.loop());
    }

    gameOver() {
        alert("Game Over");
        location.reload();
    }
}

const game = new ArcadeGame();
